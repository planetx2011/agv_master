define(function(require){
  var e = require('./e1')
  return e
})