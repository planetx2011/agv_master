global.SPECS_MODULES_ASYNC = true
