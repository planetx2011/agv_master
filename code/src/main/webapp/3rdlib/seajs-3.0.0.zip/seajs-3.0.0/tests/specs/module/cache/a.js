
global.cache_g++

define(function(require, exports) {
  exports.name = 'a'
});


