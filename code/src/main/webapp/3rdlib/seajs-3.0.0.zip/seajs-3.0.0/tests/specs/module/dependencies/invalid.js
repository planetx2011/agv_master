define('', ['', null, undefined], function(require, exports, mod) {
  exports.dependencies = mod.dependencies
});
