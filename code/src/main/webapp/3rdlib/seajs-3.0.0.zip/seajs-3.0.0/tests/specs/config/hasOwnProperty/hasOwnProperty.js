define(function(){

  return { name: 'hasOwnProperty' }

});
