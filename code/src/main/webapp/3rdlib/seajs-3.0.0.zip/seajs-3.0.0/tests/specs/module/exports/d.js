define({
  foo: 'd'
});
