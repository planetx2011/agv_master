define(function(require){
  var d = require('./d')
  return d
})